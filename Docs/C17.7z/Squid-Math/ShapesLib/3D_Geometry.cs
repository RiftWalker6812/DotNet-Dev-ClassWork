﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squid_Math.ShapesLib
{
    class _3D_Geometry
    {
    }

    //3D Shapes
    public class Hexagon { }
    public class Cirlce { }
    public class Square { }
}
